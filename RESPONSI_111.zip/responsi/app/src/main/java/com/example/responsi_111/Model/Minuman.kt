package com.example.responsi_111.Model

class Minuman {
    var name: String = ""
    var detail: String = ""
    var poster: Int = 0
}